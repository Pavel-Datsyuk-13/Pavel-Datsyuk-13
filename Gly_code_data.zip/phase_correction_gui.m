function ang = phase_correction_gui(testspec, x)
% GUI for visualizing phase correction. Inputs are your spec (prob after
% GannetLoad) and the ppm axis (also from GL)
% you can type in an angle, use the slider or click the arrows till spec
% looks phased. This only returns the angle, it does not apply the phasing 
% do that after if you want to. -justin s April 2025.

warning('off', 'MATLAB:plot:IgnoreImaginaryXY');

%initial angle
    ang = 0;

    fig = figure('Name', 'Phase Correction GUI', 'NumberTitle', 'off', ...
                 'Position', [100, 100, 600, 400], ...
                 'CloseRequestFcn', @close_gui); 

    slider = uicontrol('Style', 'slider', 'Min', -180, 'Max', 180, ...
                       'Value', ang, 'Units', 'normalized', ...
                       'Position', [0.3, 0.05, 0.4, 0.05], ...
                       'Callback', @update_from_slider);

    % text box for manual angle entry
    edit_box = uicontrol('Style', 'edit', 'Units', 'normalized', ...
                         'Position', [0.8, 0.85, 0.15, 0.05], ...
                         'String', num2str(ang), 'FontSize', 12, ...
                         'Callback', @update_from_text);

    angle_label = uicontrol('Style', 'text', 'Units', 'normalized', ...
                            'Position', [0.4, 0.12, 0.2, 0.05], ...
                            'String', sprintf('Phase Angle: %.1f°', ang), ...
                            'FontSize', 12);

    %init plot
    ax = axes('Parent', fig, 'Position', [0.1, 0.25, 0.8, 0.6]);
    plot_data(ang);

    %pauses until figure is closed
    uiwait(fig);

    %update plot from slider
    function update_from_slider(~, ~)
        ang = get(slider, 'Value'); 
        set(edit_box, 'String', num2str(ang, '%.1f')); 
        update_plot();
    end

    % or update plot from text input
    function update_from_text(~, ~)
        temp_ang = str2double(get(edit_box, 'String')); 
        if isnan(temp_ang) || temp_ang < -180 || temp_ang > 180
            temp_ang = ang;
        end
        ang = temp_ang; % updates stored angle! - this part was very sensitive for some rzn...
        set(slider, 'Value', ang); 
        update_plot();
    end

    %updating the plot
    function update_plot()
        plot_data(ang);
        set(angle_label, 'String', sprintf('Phase Angle: %.1f°', ang)); 
        drawnow;
    end

    % plotting
    function plot_data(ang)
        pc_spec = testspec * pshift(ang);
        plot(ax, x, pc_spec, 'k');
        xlim([0.5, 3.5]); % Justin commenting out for now (9/22/25)
        %xlim([-2, 10]); 
        % xlim([-2, 8]); 
        set(gca, 'XDir', 'reverse');
        title(['PS angle: ', num2str(ang), char(0176)]);
        grid on;
    end

    % closes and returns the angle u closed the fig on 
    function close_gui(~, ~)
        uiresume(fig); 
        delete(fig);   % this got deleted somehow 
    end 
end
    