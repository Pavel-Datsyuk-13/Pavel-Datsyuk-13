%This is essentiall the same as the WritedotMATjrs_v2, but it is more catered to 
% DIFF spec analysis Further stats and plotting are below

clc
clearvars
data_path = 'pathtodata';

%extract all folders
folder_path = dir(fullfile(data_path));
all_folders_og = folder_path([folder_path.isdir]);
all_folders_og = all_folders_og(~ismember({all_folders_og.name}, {'.','..','PC_FC_testing','P3'}));
all_folders_og = {all_folders_og.name};
all_folders = repelem(all_folders_og,1, 2);
all_folders = convertStringsToChars(all_folders);
Gaba_concs = zeros(length(all_folders_og),2); %change for the number of patients
Gaba_areas = Gaba_concs;
Glx_areas= Gaba_concs;
Glx_concs= Gaba_concs;
te68diff = zeros(length(all_folders_og), 4096);
te64diff = te68diff;
telabel= {'64 ms','68 ms'};


%outerloop for per patient
for pat_idx = 7%:length(all_folders_og) %change 1 to 2,3,4 etc if you already processed them
    current_folder = all_folders{pat_idx*2};

    %this should automatically pull out the files you need
    current_path = fullfile(data_path, current_folder);
    all_files = dir(fullfile(current_path,'*', '*.SDAT')); % Get all .SDAT files in current/sub folder(s)
    file_names = {all_files.name}; % Extract file names


    data_files = {file_names(contains(file_names, 'Edit') & contains(file_names, 'TE_64') & contains(file_names, 'act')),...
        file_names(contains(file_names, 'Edit') & contains(file_names, 'TE_68') & contains(file_names, 'act'))};

    wat_ref_files = {file_names(contains(file_names, 'Edit') & contains(file_names, 'TE_64') & contains(file_names, 'ref')),...
        file_names(contains(file_names, 'Edit') & contains(file_names, 'TE_68') & contains(file_names, 'ref'))};

    %change directory for each patient
    %changes folder name per patient
    folder_prefix = char(data_files{2});
    folder_prefix = [folder_prefix(1:8),'/'];

    for subj_idx = 1%:2 %:length(data_files) doing 64 ms now 
        all_folders_og=all_folders{subj_idx};
        specinput =  strcat(data_path, current_folder,'/',folder_prefix, data_files{subj_idx});
        waterinput = strcat(data_path, current_folder,'/',folder_prefix, wat_ref_files{subj_idx});


        MRS_struct = GannetLoad(specinput, waterinput);
        spec = MRS_struct.spec.AllFramesFTrealign;
        MRS_struct = GannetFit(MRS_struct);

        if subj_idx == 1
            te64diff(pat_idx,:) = MRS_struct.spec.vox1.GABAGlx.diff_scaled;
            Gaba_areas(pat_idx, subj_idx)= MRS_struct.out.vox1.GABA.Area; %area value
            Gaba_concs(pat_idx, subj_idx)= MRS_struct.out.vox1.GABA.ConcIU; %concentraion value
            Glx_areas(pat_idx, subj_idx)= MRS_struct.out.vox1.Glx.Area; %area value
            Glx_concs(pat_idx, subj_idx)= MRS_struct.out.vox1.Glx.ConcIU; %concentraion value

        else %68 ms
            te68diff(pat_idx,:) = MRS_struct.spec.vox1.GABAGlx.diff_scaled;
            Gaba_areas(pat_idx, subj_idx)= MRS_struct.out.vox1.GABA.Area; %area value
            Gaba_concs(pat_idx, subj_idx)= MRS_struct.out.vox1.GABA.ConcIU; %concentraion value
            Glx_areas(pat_idx, subj_idx)= MRS_struct.out.vox1.Glx.Area; %area value
            Glx_concs(pat_idx, subj_idx)= MRS_struct.out.vox1.Glx.ConcIU; %concentraion value
        end
        %save(namesave, 'MRS_struct')
    end

end

% MRS_struct.out.vox1.GABA.ConcIU --> concentration value
% MRS_struct.out.vox1.GABA.Area --> area value
%ppm_range= find(MRS_struct.spec.freq < 4.2 & MRS_struct.spec.freq > 1);
%ppm_range2= find(MRS_struct.spec.freq < 4.2 & MRS_struct.spec.freq > 1.8);

%for visualizatoin
% figure()
% plot(MRS_struct.spec.freq(ppm_range), real(MRS_struct.spec.vox1.GABAGlx.diff(ppm_range)),'-k',LineWidth=1)
% xlim([1 4.2])
% hold on
% % plot(MRS_struct.spec.freq(ppm_range2), real(testing(ppm_range2)),'-r',LineWidth=1)
% set(gca, 'XDir', 'Reverse')
% title([current_folder, ' DIFF spectrum at ',telabel{subj_idx}])
%%
ppm_range2= find(MRS_struct.spec.freq < 4.2 & MRS_struct.spec.freq > 1.8);
figure()
plot(MRS_struct.spec.freq, MRS_struct.spec.vox1.GABAGlx.diff, 'k')
hold on
plot(freq(ppm_range2), GABAGlxModel(GaussModelParam,freq(ppm_range2)), 'r')
set(gca, 'XDir', 'Reverse')
xlim([2.8 4.1])
box off

%% Looking at areas and concentrations

for jj = 1:2
    avggabaarea(jj) = mean(Gaba_areas(:,jj));
    stdgabaarea(jj) = std(Gaba_areas(:,jj));
    avggabaconc(jj) = mean(Gaba_concs(:,jj));
    stdgabaconc(jj) = std(Gaba_concs(:,jj));
    avgglxarea(jj) =  mean(Glx_areas(:,jj));
    stdglxarea(jj) =  std(Glx_areas(:,jj));
    avgglxconc(jj) =  mean(Glx_concs(:,jj));
    stdglxconc(jj) =  std(Glx_concs(:,jj));
end


figure()
%GABA Area
subplot(2,2,1);
bar(avggabaarea);
hold on
errorbar(avggabaarea,stdgabaarea, 'k.');
xticklabels({'64 ms', '68 ms'});
ylim([0 0.6])
title('Average GABA Area');


%GABA Concentration
subplot(2,2,2);
bar(avggabaconc);
hold on
errorbar(avggabaconc, stdgabaconc, 'k.');
xticklabels({'64 ms', '68 ms'});
ylim([0 3.25])
title('Average GABA Concentration');

%Glx Area
subplot(2,2,3);
bar(avgglxarea);
hold on
errorbar(avgglxarea, stdglxarea, 'k.');
xticklabels({'64 ms', '68 ms'});
ylim([0 0.4])
title('Average Glx Area');

%Glx Concentration
subplot(2,2,4);
bar(avgglxconc);
hold on
errorbar(avgglxconc, stdglxconc, '.');
xticklabels({'64 ms', '68 ms'});
title('Average Glx Concentration');

%% Plotting diff specs

for jj = 1:6
    figure(jj)
    plot(ppmaxis, te64diff(jj,:),'k');
    hold on
    plot(ppmaxis, te68diff(jj,:), 'r');
    set(gca, 'XDir','reverse')
    xlim([2.2 4])
    title('Black: diff64   Red: diff68')
end

%%

mean_GABA_conc_64 = mean(Gaba_concs(:,1));
std_GABA_conc_64 = std(Gaba_concs(:,1));
mean_GABA_conc_68 = mean(Gaba_concs(:,2));
std_GABA_conc_68 = std(Gaba_concs(:,2));

mean_GABA_area_64 = mean(Gaba_areas(:,1));
std_GABA_area_64 = std(Gaba_areas(:,1));
mean_GABA_area_68 = mean(Gaba_areas(:,2));
std_GABA_area_68 = std(Gaba_areas(:,2));

%%CV for IV GABA concs
cv_data = horzcat(Gaba_concs(:,1),Gaba_concs(:,2));
mean_cv = mean(cv_data);
std_cv = std(cv_data);
CV_GABA_IV = 100*(std_cv/mean_cv);

[p1,h1,stats1] = ranksum(Gaba_concs(:,1), Gaba_concs(:,2));
[p2,h2,stats2] = ranksum(Gaba_areas(:,1), Gaba_areas(:,2));