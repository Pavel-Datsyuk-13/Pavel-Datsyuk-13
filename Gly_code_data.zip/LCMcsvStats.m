%%This can help visual LCM outputs depending on how you organise them
%further visualizations are included here, but will be excluded most of
% the time.

clearvars
% Set reference directory that includes all desired .csv files
baseDir = 'datapath'; % change this
folders=plist(1,7);%1st number is start patient, second is stop patient
%removing patient 3 bc movement
findP3 = contains(folders, 'P3');
folders(findP3)=[];

% List of metabolites in the path / basis set  PROB HAVE TO CHANGE THIS
metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln', 'Gly',...
    'GPC', 'GSH', 'Ins', 'Lac', 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};
% ^^^^ all of that is stuff you will change ^^^^

%finding number of csv files 
cd([baseDir '/P1'])
num_csvs = size(dir(fullfile(pwd, '**', '*.csv')),1);
cd ..

%Index for extracting out of CSV
Conc_stop = length(metabs)*3;
CRLB_stop = Conc_stop+1;

for fold_idx = 1:length(folders)
    % Initialize loop #'s and arrays for storage
    if fold_idx==1
        num_metabs = length(metabs);
        num_pats = length(folders);
        all_concs = zeros(num_csvs, num_metabs, num_pats);
        all_sdevs = zeros(num_csvs, num_metabs, num_pats);
    end

    current_folder=folders{fold_idx};
    currentDir=strcat(baseDir,current_folder);
    % Get list of all CSV files (including subfolders)
    csvFilesStruct = dir(fullfile(currentDir, '**', '*.csv'));
    csv_files = fullfile({csvFilesStruct.folder}, {csvFilesStruct.name});
    csv_files = csv_files([1 3 2 4]); % puts this in OFF 64, SUM 64, OFF 68, SUM 68.
    plot_indices = 1:length(metabs);

    %this loop extracts the data from the csv's
    for csv_idx = 1:num_csvs
        table = readtable(csv_files{csv_idx});
        conctable = table(:,3:3:Conc_stop); % Concentrations
        sdevtable = table(:,4:3:CRLB_stop); % CRLBs

        % Store data for metabolites: 1st dim is scan type, 2nd is metobilte, 3rd is for each patient
        all_concs(csv_idx,:,fold_idx) = table2array(conctable(1, plot_indices));
        all_sdevs(csv_idx,:, fold_idx) = table2array(sdevtable(1, plot_indices));
    end

end
%% Scatterplots

OFF64 = all_concs(1,:,:);
OFF68 = all_concs(2,:,:);
SUM64 = all_concs(3,:,:);
SUM68 = all_concs(4,:,:);
plot_metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln', 'Gly',...
    'GPC', 'GSH', 'Lac', 'mI', 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};

for q = [5 8 12]

    OFF64_met = squeeze(OFF64(:,q,:));
    OFF68_met = squeeze(OFF68(:,q,:));
    SUM64_met = squeeze(SUM64(:,q,:));
    SUM68_met = squeeze(SUM68(:,q,:));

    %plot the correlations
    figure(q)
    subplot(2,2,1)
    plot(OFF68_met, SUM68_met,'ob','MarkerFaceColor', 'b', 'MarkerSize', 4);
    grid on;
    xlabel('OFF 68','fontweight','bold');
    ylabel('SUM 68','fontweight','bold');

    subplot(2,2,2)
    plot(OFF64_met, SUM64_met,'ob','MarkerFaceColor', 'b', 'MarkerSize', 4);
    grid on;
    xlabel('OFF 64','fontweight','bold');
    ylabel('SUM 64','fontweight','bold');

    subplot(2,2,3)
    plot(SUM64_met, SUM68_met,'ob','MarkerFaceColor', 'b', 'MarkerSize', 4);
    grid on;
    xlabel('SUM 64','fontweight','bold');
    ylabel('SUM 68','fontweight','bold');


    subplot(2,2,4)
    plot(OFF64_met, OFF68_met,'ob','MarkerFaceColor', 'b', 'MarkerSize', 4);
    grid on;
    xlabel('OFF 64','fontweight','bold');
    ylabel('OFF 68','fontweight','bold');
    sgtitle([plot_metabs{q}, ' Correlation'],fontsize=18);

end



%% Boxplots of Concentrations

metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln', 'Gly',...
    'GPC', 'GSH', 'Lac', 'mI' 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};

plotting_concs = all_concs;

for frank = [5 8 12] % only plotting Glc, Gly, and mI 
    conc_squish = squeeze(plotting_concs(:,frank,:));
    figure('Renderer', 'painters', 'Position', [10 10 1200 800])
    conc_squish = conc_squish';
    data = conc_squish(:);
    group = repelem(1:4, 6)';
    boxplot(conc_squish, 'Colors','k')
    hold on
    % Overlay data points (i think this looks more aesthetic) 
    for g = 1:4
        idx = group == g;
        x = randn(sum(idx),1)*0.05 + g;      
        scatter(x, data(idx),150, 'filled', 'MarkerFaceAlpha', 0.6)
    end
    xticks(1:4)
    xticklabels({'OFF 64','SUM 64','OFF 68','SUM 68'})
    ylabel('Concentration (i.u.)', 'FontSize',18, 'FontName','Arial')
    title([metabs{frank},' in Vivo Concentrations'],'FontSize',30,'FontName','Arial')
    ax = gca;
    ax.XAxis.FontSize = 20;
    ax.YAxis.FontSize = 24;
    ax.XAxis.FontName = 'Arial';
    box off

    % Change Linewidth for all boxplot elements
    set(findobj(gca,'Tag','Box'),'LineWidth',2)
    set(findobj(gca,'Tag','Whisker'),'LineWidth',1)
    set(findobj(gca,'Tag','Median'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Lower Whisker'),'LineWidth',1)
    set(findobj(gca,'Tag','Upper Whisker'),'LineWidth',1)
    set(findobj(gca,'Tag','Upper Adjacent Value'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Lower Adjacent Value'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Outliers'),'MarkerSize',4) %Make outliers larger

end
%% Plotting CRLBs
metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln', 'Gly',...
    'GPC', 'GSH', 'Lac', 'mI' 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};

% swap order to 64 off sum then 68 off sum
plotting_concs = all_sdevs;

for frank = [5 8 12]
    conc_squish = squeeze(plotting_concs(:,frank,:));
    figure('Renderer', 'painters', 'Position', [10 10 1200 800])
    conc_squish = conc_squish';
    data = conc_squish(:);
    group = repelem(1:4,6)';
    boxplot(conc_squish)
    hold on
    % Overlay individual data points with jitter
    for g = 1:4
        idx = group == g;
        x = randn(sum(idx),1)*0.05 + g;       % Add jitter to x-axis around group index
        scatter(x, data(idx),150, 'filled', 'MarkerFaceAlpha', 0.6)
    end
    xticks(1:4)
    xticklabels({'OFF 64','SUM 64','OFF 68','SUM 68'})
    ylabel('CRLB (%)')
    title([metabs{frank},' in Vivo CRLB'],'FontSize',30,'FontName','Arial')
    ylim([0 37])
    box off
    ax = gca;
    ax.XAxis.FontSize = 20;
    ax.YAxis.FontSize = 24;
    ax.XAxis.FontName = 'Arial';

    % Change Linewidth for all boxplot elements
    set(findobj(gca,'Tag','Box'),'LineWidth',2)
    set(findobj(gca,'Tag','Whisker'),'LineWidth',1)
    set(findobj(gca,'Tag','Median'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Lower Whisker'),'LineWidth',1)
    set(findobj(gca,'Tag','Upper Whisker'),'LineWidth',1)
    set(findobj(gca,'Tag','Upper Adjacent Value'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Lower Adjacent Value'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Outliers'),'MarkerSize',4) %Make outliers larger

end


%% Getting data for the CV graphs (MAY 30TH 2025)

tableidx=1;
cv64 = zeros(1,6);
cv68 = cv64;


for kk = [5 8 12]
    thisconc = squeeze(all_concs(:,kk,:));
    for ll = 1:size(thisconc,2)
        offf64 = thisconc(1,ll);
        summ64 = thisconc(2,ll);
        offf68 = thisconc(3,ll);
        summ68 = thisconc(4,ll);

        cv64(tableidx, ll)= 100*(abs((offf64- summ64) / mean(offf64 + summ64)));
        cv68(tableidx,ll)= 100*(abs((offf68- summ68) / mean(offf68 + summ68)));
    end
    tableidx=tableidx+1;
end

% Mann-Whittney u test
stats_store = zeros(3,3);
for jj = 1:3
    [p,h,stats]= ranksum(cv64(jj,:),cv68(jj,:));
    stats_store(jj, 1)= p;
    stats_store(jj, 2)= h;
    stats_store(jj, 3)= stats.ranksum;
end

% Prepare data
cv64_long = cv64';
cv68_long = cv68';
data_all = [cv64_long(:); cv68_long(:)];

group = [ ...
    repelem(1:3,6)';
    repelem(1:3,6)' ];

category = [...
    repmat(1,18,1);
    repmat(2,18,1)  ];

% Plot boxplots
figure('Renderer', 'painters', 'Position', [10 10 1200 800])
boxplot(data_all, {group, category}, 'FactorSeparator', 1, ...
    'Colors', 'kb', 'Widths', .4, 'Symbol', ''); % Remove default outliers

set(gca, 'XTickLabel', {'Glc', 'Gly', 'mI'});
xtickangle(45)

% Adjust spacing between pairs
set(gca,'XTick', [1.5 3.5 5.5]);
xlim([0.5 6.5])

hold on

% Plot data points in different colors
rng(1) % For reproducibility
uniqueGC = unique([group category], 'rows');
for i = 1:size(uniqueGC,1)
    g = uniqueGC(i,1);
    c = uniqueGC(i,2);

    % Find corresponding indices
    idx = (group == g) & (category == c);

    % Generate random jitter around x positions (width = 0.08)
    xBase = (g-1)*2 + c; % Adjust x position based on boxplot layout
    xJitter = xBase + 0.08*randn(sum(idx),1);

    if c == 1
        ptColor = '#0a3aff';
    else
        ptColor = '#ff0d0d';
    end

    scatter(xJitter, data_all(idx), 100, 'filled', 'MarkerFaceAlpha', 0.7, ...
        'MarkerFaceColor', ptColor, 'MarkerEdgeColor', 'k');

end

% Legend
h = findobj(gca,'Tag','Box');
%legend([h(6), h(5)], {'64ms','68ms'}, 'Location', 'northeast');

ylabel('Coefficient of Variation (%)','FontSize',18, 'FontName','Arial')
title('In Vivo CV (64ms vs 68ms)','FontSize',24, 'FontName','Arial','FontWeight','bold')
box off
ax = gca;
ax.XAxis.FontSize = 20;
ax.YAxis.FontSize = 24;
ax.XAxis.FontName = 'Arial';

% Change Linewidth for all boxplot elements
set(findobj(gca,'Tag','Box'),'LineWidth',1)
set(findobj(gca,'Tag','Whisker'),'LineWidth',1)
set(findobj(gca,'Tag','Median'),'LineWidth',1)
set(findobj(gca,'Tag','Lower Whisker'),'LineWidth',1)
set(findobj(gca,'Tag','Upper Whisker'),'LineWidth',1)
set(findobj(gca,'Tag','Upper Adjacent Value'),'LineWidth',1)
set(findobj(gca,'Tag','Lower Adjacent Value'),'LineWidth',1)
set(findobj(gca,'Tag','Outliers'),'MarkerSize',4) %Make outliers larger

%% Table for cv btw subject
storage = zeros(3,4);

tableidx=1;

for kk = [5 8 12]
    thisconc = squeeze(all_concs(:,kk,:));
    for ll = 1:size(all_concs,3)
        offf64 = std(thisconc(1,:)) / mean(thisconc(1,:));
        summ64 = std(thisconc(2,:)) / mean(thisconc(2,:));
        offf68 = std(thisconc(3,:)) / mean(thisconc(3,:));
        summ68 = std(thisconc(4,:)) / mean(thisconc(4,:));
    end

    storage(tableidx,1)=offf64;
    storage(tableidx,2)=summ64;
    storage(tableidx,3)=offf68;
    storage(tableidx,4)=summ68;

    tableidx=tableidx+1;
end

storage = 100.*storage;

%% Table for concentrations 
allmeans = zeros(4, 3);
allstds = zeros(4, 3);
idx = 1;

for ii = [5 8 12]
    working_conc = squeeze(all_concs(:,ii,:));
    allmeans(:,idx)= mean(working_conc, 2);
    allstds(:,idx)= std(working_conc',1);
    idx = idx+1;
end


%% p-values for CV comp
filler = zeros(1,3)
 
for jj = 1:3
    [p,h,stats] = ranksum(cv64(jj,:), cv68(jj,:))
    filler(jj) = p;
end 
