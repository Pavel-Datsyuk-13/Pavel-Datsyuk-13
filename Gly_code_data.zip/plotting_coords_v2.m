%Used to general Plots with spectra +/- Gly fitted 
%This can also be used in gernal to display coord LCM outputs
clearvars


%name = 'OFF 64';
%name = 'SUM 64'
%name = 'OFF 68'
name = 'SUM 68';

pathloop = {'path1/', 'path2'};

%coord_file = 'coord-LCM_MP_OFF_64ms_3T_sl1_1-1.coord';
%coord_file = 'coord-LCM_MP_SUM_64ms_3T_sl1_1-1.coord';
%coord_file = 'coord-LCM_MP_OFF_68ms_3T_sl1_1-1.coord';
coord_file = 'coord-LCM_MP_SUM_68ms_3T_sl1_1-1.coord';

greenorred= {'#40802b','#ff0000'};
figure('Position', get(0, 'ScreenSize'))

for ii = 1:length(pathloop)
out_spec = io_readlcmcoord_getBackground([pathloop{ii}, coord_file],'sp');
baseline = io_readlcmcoord_getBackground([pathloop{ii}, coord_file],'bg');
out_spec.specs = out_spec.specs-baseline.specs;

if ii==1
    frank1 = out_spec.specs;
    out_spec.specs(1:10,:) = []; %bc LCM output weird - Justin
    out_spec.ppm(1:10,:) = []; 

elseif ii == 2
    frank2 = out_spec.specs;
    out_spec.specs = out_spec.specs+ 5 *(mean(out_spec.specs));
end 

if ii == 2
    offset = 1.05*real(out_spec.specs(end-200,:))
    offset1 = 0.95*real(out_spec.specs(end-200,:))
else 
    offset = 1.35*real(out_spec.specs(end-200,:))
    offset1 = 0.65*real(out_spec.specs(end-200,:))
end



this_coord = [pathloop{ii}, coord_file];
xLimits = [1 4.1];
xLimitsText = xLimits(1) -0.03;
FontSize = 16;
LineWidth = 1.5;

% read in LCModel coord outputs
out_fit = io_readlcmcoord_getBackground(this_coord,'fit');
out_fit.specs = out_fit.specs - baseline.specs;
if ii==1 
out_fit.specs(1:10,:) = []; %same issue as above 
out_fit.ppm(1:10,:) = []; 
end 



p = plot(out_spec.ppm, out_spec.specs,'k');
for plots = 1:length(p)
    set(p(plots),'LineWidth',LineWidth);
end

hold on

if ii == 2
    out_fit.specs = out_fit.specs+ 5*(mean(out_fit.specs));
end 
p = plot(out_spec.ppm, out_fit.specs, 'color', greenorred{ii});



for plots = 1:length(p)
     set(p(plots),'LineWidth',LineWidth);
end

hold on

if ii==1
    sidelabela = '   Data   ';
    sidelabelb = 'Fit + Gly';
else 
    sidelabela = '   Data   ';
    sidelabelb = 'Fit - Gly';
end 


text(xLimitsText, offset, sidelabela, 'FontSize', FontSize,'Color','k');
text(xLimitsText, offset1, sidelabelb, 'FontSize', FontSize,'Color',greenorred{ii});

end 


set(gca, 'XLim', xLimits)
set(gca, 'XDir', 'reverse')
title(name,'FontSize',24,'FontName','Arial','Color','k')
set(gca,'box','off')
yticks([])
yticklabels([])
xlabel('(ppm)','FontSize',22)
ax = gca;
ax.XAxis.FontSize = 20;
ax.XAxis.FontName = 'Arial';
ax.XAxis.Color = 'k';
