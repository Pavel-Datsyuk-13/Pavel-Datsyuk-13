% this script puts the in vivo data into the LCM readable format
clearvars

saveDestination = "desktoppath"; 
outtrunk = 'Bio HPC folder';
this_te = [64 68 64 68];
title = {'OFF 64','OFF 68','SUM 64','SUM 68'};


lcm_loc = '/home2/username/.lcmodel/bin'; 


these_files = {'OFF_64.mat','SUM_64.mat','OFF_68.mat','SUM_68.mat'};


file_names = {'LCM_MP_OFF_64ms_3T.RAW','LCM_MP_SUM_64ms_3T.RAW','LCM_MP_OFF_68ms_3T.RAW','LCM_MP_SUM_68ms_3T.RAW',};



for f_idx = 1:length(these_files)

load(saveDestination + these_files{f_idx});
spec = spec.*-1;
mc_spec = spec;
spec=-1*(mc_spec(end:-1:1));
npts = 4096;
all_fids = zeros([2,2,npts]);
ph=0;

for x = 1:2
    for y = 1:2
        temp_img = spec;
        this_fid = ifft(ifftshift(temp_img'));
        this_fid = this_fid(end:-1:1)';
        all_fids(x,y,:) = this_fid*exp(-1i*pi*ph/180);
    end
end

A = permute(all_fids, [3 1 2]);
filetxt=file_names{f_idx};


C = reshape(A,size(A,1),size(A,2)*size(A,3)); 

% code to save data in a LCModel format
% partly copied from Ioannis' MRSpectro_S\MR_spectroS-master\algorithms\@MR_spectroS\ExportLcmRaw.m

imagesize=2;
HZPPM=127.74;
PatientID='5';
TE=this_te(f_idx); %2.3;
filename = strcat(filetxt);
fileID = fopen(filename,'w');

fprintf(fileID,' %s\n', '$SEQPAR');
fprintf(fileID,' %s = %.2f\n', 'ECHOT', TE);
fprintf(fileID,' %s= %3.4f\n', 'HZPPM', HZPPM);
fprintf(fileID,' %s = %c%s%c\n','SEQ', char(39), 'FID', char(39));
fprintf(fileID,' %s\n', '$END');

%NMID Namelist
fprintf(fileID,' %s\n', '$NMID');
fprintf(fileID,' ID=%c%d%c\n', char(39), PatientID, char(39));
fprintf(fileID,' FMTDAT=%c(2E15.6)%c\n',char(39),char(39));
fprintf(fileID,' BRUKER= T\n'); 
fprintf(fileID,' %s\n', '$END');


pos1=1:imagesize; pos2=1:imagesize;
for pos1Loop=1:imagesize
    for pos2Loop=1:imagesize
        voxelLoop=pos1(pos2Loop)+imagesize*(pos2(pos1Loop)-1);
        for timeloop=1:size(A,1)
            w=C(timeloop,voxelLoop);
            fprintf(fileID,'%15.6E%15.6E\n', real(w), imag(w));
        end
    end
end
%fclose(fileID);
%clearvars -except these_files these_files_wat file_names wat_file_names f_idx spec out_file_path saveDestination title lcm_loc LCMparam fileID fileID_sh this_te
end


