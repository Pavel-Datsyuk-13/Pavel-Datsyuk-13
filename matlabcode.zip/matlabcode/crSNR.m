function SNRestimate = crSNR(inspec)
%crSNR takes input spec and estimates SNR based on the Cr peak

if size(inspec,1) > size(inspec,2)
    inspec= inspec';
end

% Get the Cr peak value for reference
Cr_peak = max(abs(real(inspec(2300:2600))));
noisesample = real(inspec(1, 134:657));%sampling in upstream range; only need real

% SG filtering to get strictly linear baseline 
% I did a really large window size on purpose (173 = closest odd # rounded down from (657-134)/3)
baseline = sgolayfilt(noisesample,2,173);
% Subtract the baselines from the real and imaginary parts
noise =  noisesample - baseline;
std_noise = std(noise);

SNRestimate= Cr_peak/std_noise;
end