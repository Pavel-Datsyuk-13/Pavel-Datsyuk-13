%This script iterates through .mat Fid-A outputs and generates spatial plots

cd('pathtodata');
te=68;
gly_coeff = 1;
mI_coeff = 1;
spec_files = dir('*.mat');
spec_files = {spec_files.name};
%% Innitialize axis and loop params
numpts = 8192; % Number of spectral points
spectral_width = 2000; % in Hz. This is how much of the frequency axis you're sampling in your acquisition
bw = linspace(-spectral_width/2, spectral_width/2, numpts);
gyromagnetic_ratio = 42.58;
field_strength = 3; % in Tesla.
ppm_axis = bw/(gyromagnetic_ratio * field_strength);
ppm_axis = ppm_axis + 4.68;

%Loop params
numfiles = length(spec_files);
on_store_allspec = zeros(8192, numfiles);
off_store_allspec = on_store_allspec;
diffspecs = on_store_allspec;
lb = 3; % Linebroadening in Hz (orignally 3 Hz)
time = (1:1:8192)/2000;  % Create a acquisition time vector divided by the spectral width
exp_lb=permute(exp(-(lb*pi*time)),[2 1]);  % Add the linebroadening onto the time vector
indx = 1; %To move from one file to the next

%% Loads in the simulated data



while indx <= numfiles % for variable number of spectra/metabolites
 
this_metabolite = spec_files{indx}; %pulls out file name
this_metabolite = load(this_metabolite); %loads it in workspace
fields = fieldnames(this_metabolite);
this_metabolite_off = this_metabolite.(fields{2});
this_metabolite_on = this_metabolite.(fields{3});


off_spat_store = zeros(19,8192,19);
on_spat_store = off_spat_store;

%doing on spec first
x_store = zeros(numpts, 19);
for x = 1:19
    y_store = zeros(numpts, 19);
    for y = 1:19

        in_off_metabolite = this_metabolite_on{x,1}{1,y}.fids.*exp_lb;
        this_metabolite_spec = fftshift(fft(in_off_metabolite));
        this_metabolite_spec = this_metabolite_spec(end:-1:1);
        spec_spatial_metabolite = permute(this_metabolite_spec,[2 1]);
        spec_spatial_metabolite = spec_spatial_metabolite';
        spec_spatial_metabolite = circshift(spec_spatial_metabolite, 880); 
        spec_spatial_metabolite = spec_spatial_metabolite(end:-1:1); 
        y_store(:, y) = spec_spatial_metabolite(:,1);


    end
    y_store = y_store';
    off_spat_store(:,:,x)=y_store();
    x_store(:,x) = (sum(y_store));
end

on_Metabolite_spec = x_store';
on_Metabolite_spec = sum(x_store, 2);
on_store_allspec(:, indx) = on_Metabolite_spec;


%same for off spec
x_store = zeros(numpts, 19);
for x = 1:19
    y_store = zeros(numpts, 19);
    for y = 1:19

        in_off_metabolite = this_metabolite_off{x,1}{1,y}.fids.*exp_lb;
        this_metabolite_spec = fftshift(fft(in_off_metabolite));
        this_metabolite_spec = this_metabolite_spec(end:-1:1);
        spec_spatial_metabolite = permute(this_metabolite_spec,[2 1]);
        spec_spatial_metabolite = spec_spatial_metabolite';
        spec_spatial_metabolite = circshift(spec_spatial_metabolite, 880); 
        spec_spatial_metabolite = spec_spatial_metabolite(end:-1:1); 
        y_store(:, y) = spec_spatial_metabolite(:,1);
    end
    y_store = y_store';
    on_spat_store(:,:,x) = y_store;
    x_store(:,x) = (sum(y_store));
end

off_Metabolite_spec = x_store';
off_Metabolite_spec = sum(x_store, 2);
off_store_allspec(:, indx) = off_Metabolite_spec;
diffspecs(:,indx)= on_Metabolite_spec - off_Metabolite_spec;

end
sum_store_allspec= on_store_allspec + off_store_allspec;


%% Finally working

specidx= {off_spat_store,on_spat_store}; % THIS IS WHAT YOU CHANGE EACH RUN
metab = 'mI';
scaleup = 1200;
scaleupsum = 1.85*scaleup;

for jj = 1:2
    specloop = specidx{jj};
    specloop = permute(specloop, [1 3 2]);
    plot_spat = [];
    addzeros = ones(1,50);
    plotrange = 3480:3532; %:3825;

    for frank = 1:19
        tempxadd = squeeze(specloop(frank,:,plotrange));
        temp_plot_off_spat = [];
        for xx = 1:19
            temp_plot_off_spat = horzcat(temp_plot_off_spat, tempxadd(xx,:));
            temp_plot_off_spat = horzcat(temp_plot_off_spat, addzeros);%add in zeros here?
        end
        plot_spat(frank, :) = temp_plot_off_spat;
    end

    % Spatial plot
    howlong = size(plot_spat, 2);
    numRows = size(plot_spat, 1);


    if jj==1
        off = plot_spat;
    elseif jj==2
        on = plot_spat;
        sum = on + off;
        diff = off-on;
    end

end 
figure()
for phrank = 1:numRows
    plot(real(off(phrank,:) + scaleup*((phrank-1))*2),'color','#1e3504')
    hold on
end
xticks([])
xticklabels([])
yticks([])
yticklabels([])
xlabel('Spatilal Z')
ylabel('Spatial Y')
title([metab,' OFF'])
hold off

figure()
for phrank = 1:numRows
    plot(real(on(phrank,:) + scaleup*((phrank-1))*2),'color','#1e3504')
    hold on
end
xticks([])
xticklabels([])
yticks([])
yticklabels([])
xlabel('Spatilal Z')
ylabel('Spatial Y')
title([metab,' ON'])
hold off

figure()
for phrank = 1:numRows
    plot(real(sum(phrank,:) + scaleupsum*((phrank-1))*2),'color','#1e3504')
    hold on
end
xticks([])
xticklabels([])
yticks([])
yticklabels([])
xlabel('Spatilal Z')
ylabel('Spatial Y')
title([metab,' SUM'])
hold off

figure()
for phrank = 1:numRows
    plot(real(diff(phrank,:) + scaleup*((phrank-1))*2),'color','#1e3504')
    hold on
end
xticks([])
xticklabels([])
yticks([])
yticklabels([])
xlabel('Spatilal Z')
ylabel('Spatial Y')
title([metab,' DIFF'])
hold off


