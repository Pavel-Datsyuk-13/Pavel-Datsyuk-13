function [freqdisplacement] = freqadjust(inputspec,pat_idx,subj_idx,x)
%Automates the freq correction
%inputs phase adjusted spec, outputs freq adjustment number

fc_spec = inputspec;
[~, NAA_Index] = max(real(fc_spec(2600:2800))); %returns where NAA peak is: make sure axis from Gannet
[~, NAA_Index] = max(real(fc_spec(2600:2800))); %returns where NAA peak is: make sure axis from Gannet
NAA_Index = NAA_Index + 2600;
Ref_index = find(abs(x - 2.0080) == min(abs(x - 2.0080)));%returns index for typical NAA peak per Govindaraju paper
freqdisplacement = Ref_index - NAA_Index; %finds index for displacement from ref to this NAA peak
end

