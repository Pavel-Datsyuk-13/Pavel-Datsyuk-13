function outputcoeff = adjustnoise(input_spec, SDofnoise,volume)
%adjust noise takes the input spectra / simulation and it's noise
%and outputs the scale for noise adjustment depending on voxel size

    scaler = 1; %for changing step-wise below to fall into snr range
    max_iters = 100; % bailing- this isually does not happen 
    counter = 0;
    SNR_value = max(real(input_spec)) / (scaler * SDofnoise);

    %Volume size scales SNR bounds
    if volume == 27
        lb = 125; 
        ub = 137;
    elseif volume == 18
        lb = 83; 
        ub = 92;
    elseif volume == 8
        lb = 37; 
        ub = 41;
    else
        fprintf(['Other voxel sizes not supported\n' ...
            'please input: 27, 18, or 8 \n'])
    end
    
    %adjust SNR scale till it falls within limits 
    while (SNR_value < lb || SNR_value > ub) 
        counter = counter + 1;
        if counter > max_iters
            disp('Too many iterations have passed, check your input variables');
            break;
        end
        if SNR_value < lb
            scaler = scaler - 0.05;
        elseif SNR_value > ub
            scaler = scaler + 0.05;
        end
        SNR_value = max(real(input_spec)) / (scaler * SDofnoise);
    end
    outputcoeff = scaler;
end
