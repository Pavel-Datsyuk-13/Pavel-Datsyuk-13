function PHRANK = pshift(angleyouaretesting)
    % PSHIFT calculates the phase shift factor.
    % Multiply your spectra by angle PHRANK to apply a phase correction. - justin
    % april 2025
    PHRANK = exp(1i * angleyouaretesting * pi / 180);
end
