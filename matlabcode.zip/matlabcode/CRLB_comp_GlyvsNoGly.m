clearvars

% Set reference directory that includes all desired .csv files
baseDir = 'pathtodata';
folders=plist(1,7);%1st number is start patient, second is stop patient
%removing patient 3 bc movement
findP3 = contains(folders, 'P3');
folders(findP3)=[];
% List of metabolites in the path
metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln', 'Gly',...
    'GPC', 'GSH', 'Ins', 'Lac', 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};
name_store = cell(6,4);

for fold_idx = 1:length(folders)
    % Initialize loop #'s and arrays for store
    if fold_idx==1
        num_metabs = length(metabs);
        num_csvs = 4;
        num_pats = length(folders);
        all_concs = zeros(num_csvs, num_metabs, num_pats);
        yes_gly_all_sdevs = zeros(num_csvs, num_metabs, num_pats);
    end
    current_folder=folders{fold_idx};
    currentDir=strcat(baseDir,current_folder);
    % Get list of all CSV files (including subfolders)
    csvFilesStruct = dir(fullfile(currentDir, '**', '*.csv'));
    csv_files = fullfile({csvFilesStruct.folder}, {csvFilesStruct.name});
    csv_files = csv_files([1 3 2 4]);
    name_store{fold_idx} =csv_files;
    plot_indices = 1:20;
    cd([currentDir,'/']);

    %this loop just extracts the data from the csv's
    for csv_idx = 1:num_csvs
        table = readtable(csv_files{csv_idx});
        conctable = table(:,3:3:60); % Mean concentrations
        sdevtable = table(:,4:3:61); % Standard deviations
        % Store data for metabolites, 3rd dim is for each patient
        all_concs(csv_idx,:,fold_idx) = table2array(conctable(1, plot_indices));
        yes_gly_all_sdevs(csv_idx,:, fold_idx) = table2array(sdevtable(1, plot_indices));
    end

end


%%
metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln', 'Gly',...
    'GPC', 'GSH', 'Lac', 'mI' 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};

% swap order to 64 off sum then 68 off sum
plotting_concs = yes_gly_all_sdevs;

for frank = [5 12]
    conc_squish = squeeze(plotting_concs(:,frank,:));
    figure()
    %conc_squish = conc_squish';
    data = conc_squish(:);
    group = repelem(1:4,6);
    boxplot(conc_squish')
    hold on
    % Overlay individual data points with jitter
    for g = 1:4
        idx = group == g;
        x = randn(sum(idx),1)*0.05 + g;       % Add jitter to x-axis around group index
        scatter(x, data(idx), 'filled', 'MarkerFaceAlpha', 0.6)
    end
    xticks(1:4)
    xticklabels({'OFF 64','SUM 64','OFF 68','SUM 68'})
    ylabel('CRLB (%)')
    title([metabs{frank},' in Vivo CRLB'])
end

%% Same but for no gly fits

baseDir = 'pathtodata'; % may have different path for no Gly fits
folders=plist(1,7);%1st number is start patient, second is stop patient
%removing patient 3 bc movement
findP3 = contains(folders, 'P3');
folders(findP3)=[];
% List of metabolites in the path
metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln',...
    'GPC', 'GSH', 'Ins', 'Lac', 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};


for fold_idx = 1:length(folders)
    % Initialize loop #'s and arrays for store
    if fold_idx==1
        num_metabs = length(metabs);
        num_csvs = 4;
        num_pats = length(folders);
        all_concs = zeros(num_csvs, num_metabs, num_pats);
        no_gly_all_sdevs = zeros(num_csvs, num_metabs, num_pats);
    end
    current_folder=folders{fold_idx};
    currentDir=strcat(baseDir,current_folder);
    % Get list of all CSV files (including subfolders)
    csvFilesStruct = dir(fullfile(currentDir, '**', '*.csv'));
    csv_files = fullfile({csvFilesStruct.folder}, {csvFilesStruct.name});
    csv_files = csv_files([1 3 2 4]);
    name_store{fold_idx} =csv_files;
    plot_indices = 1:19;
    cd([currentDir,'/']);

    %this loop just extracts the data from the csv's
    for csv_idx = 1:num_csvs
        table = readtable(csv_files{csv_idx});
        conctable = table(:,3:3:60); % Mean concentrations
        sdevtable = table(:,4:3:61); % Standard deviations
        % Store data for metabolites, 3rd dim is for each patient
        all_concs(csv_idx,:,fold_idx) = table2array(conctable(1, plot_indices));
        no_gly_all_sdevs(csv_idx,:, fold_idx) = table2array(sdevtable(1, plot_indices));
    end

end
clc

%%
metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln',...
    'GPC', 'GSH', 'Lac', 'mI' 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};

% swap order to 64 off sum then 68 off sum
plotting_concs = no_gly_all_sdevs;

for frank = [5 11] % index to metabolites 
    conc_squish = squeeze(plotting_concs(:,frank,:));
    figure()
    %conc_squish = conc_squish';
    data = conc_squish(:);
    group = repelem(1:4,6);
    boxplot(conc_squish')
    hold on
    % Overlay individual data points with jitter
    for g = 1:4
        idx = group == g;
        x = randn(sum(idx),1)*0.05 + g;       % Add jitter to x-axis around group index
        scatter(x, data(idx), 'filled', 'MarkerFaceAlpha', 0.6)
    end
    xticks(1:4)
    xticklabels({'OFF 64','SUM 64','OFF 68','SUM 68'})
    ylabel('CRLB (%)')
    title([metabs{frank},' in Vivo CRLB'])
end
%%
metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln', 'Gly',...
    'GPC', 'GSH', 'Lac', 'mI', 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};

% These would be defined earlier in your script
data1 = yes_gly_all_sdevs;
data2 = no_gly_all_sdevs;

metab_indices1 = [5 12];  % For data1
metab_indices2 = [5 11];  % For data2

% Assuming data1 and data2 are already defined:
for i = 1:length(metab_indices1)
    idx1 = metab_indices1(i);
    idx2 = metab_indices2(i);

    conc1 = squeeze(data1(:, idx1, :));
    conc2 = squeeze(data2(:, idx2, :));

    % Create the figure
    figure()

    % Get boxplot groups and x-ticks (same for both)
    group = repelem(1:4,6);
    xtick_labels = {'OFF 64','SUM 64','OFF 68','SUM 68'};

    % Boxplot for conc1
    boxplot(conc1', 'Positions', [1 2 3 4] - 0.15, 'Colors', 'r', 'Widths', 0.2)
    hold on
    % Boxplot for conc2
    boxplot(conc2', 'Positions', [1 2 3 4] + 0.15, 'Colors', 'b', 'Widths', 0.2)

    % Scatter for conc1
    data_flat1 = conc1(:);
    for g = 1:4
        idx = group == g;
        x = randn(sum(idx),1)*0.05 + g - 0.15;
        scatter(x, data_flat1(idx), 40, 'filled', 'MarkerFaceAlpha', 0.7)
    end

    % Scatter for conc2
    data_flat2 = conc2(:);
    for g = 1:4
        idx = group == g;
        x = randn(sum(idx),1)*0.05 + g + 0.15;
        scatter(x, data_flat2(idx), 40, 'filled', 'MarkerFaceAlpha', 0.7)
    end

    % Labels
    xticks(1:4)
    xticklabels(xtick_labels)
    ylabel('CRLB (%)')
    title([metabs{idx1},  ' in Vivo CRLB +/- Gly Inclusion'])
    legend({'Gly +','Gly -'}, 'Location', 'best')
    hold off
end

%%
metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln', 'Gly',...
    'GPC', 'GSH', 'Lac', 'mI', 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};

% custom colors (preference)
blue_dark = [0, 0, 139]/255;     % #00008B
red_dark = [139, 0, 0]/255;      % #8B0000

% These would be defined earlier in your script
% data1 = yes_gly_all_sdevs;
% data2 = no_gly_all_sdevs;

metab_indices1 = [5 12];  % For data1
metab_indices2 = [5 11];  % For data2

for i = 1%1:length(metab_indices1)
    idx1 = metab_indices1(i);
    idx2 = metab_indices2(i);

    conc1 = squeeze(data1(:, idx1, :));
    conc2 = squeeze(data2(:, idx2, :));

    yesgly = conc1;
    nogly = conc2;

    for ii = 1:size(nogly,1)
        temp_no = nogly(ii,:)
        temp_yes = yesgly(ii,:)
        [p,h,stats]= ranksum(temp_no,temp_yes);
        teststore(ii, 1)= p;
        teststore(ii, 2)= h;
        teststore(ii, 3)= stats.ranksum;
    end


    % Create the figure
    figure('Renderer', 'painters', 'Position', [10 10 1200 800])

    % Get boxplot groups and x-ticks (same for both)
    group = repelem(1:4,6);
    xtick_labels = {'OFF 64','SUM 64','OFF 68','SUM 68'};

    % Boxplot for conc1
    boxplot(conc1', 'Positions', [1 2 3 4] - 0.15, 'Colors', blue_dark, 'Widths', 0.2)
    hold on
    % Boxplot for conc2
    boxplot(conc2', 'Positions', [1 2 3 4] + 0.15, 'Colors', red_dark, 'Widths', 0.2)

    % Scatter for conc1
    conc1=conc1';
    data_flat1 = conc1(:);
    for g = 1:4
        idx = group == g;
        x = randn(sum(idx),1)*0.05 + g - 0.15;
        scatter(x, data_flat1(idx), 100, 'filled', 'MarkerFaceColor', blue_dark, 'MarkerFaceAlpha', 0.5)
    end

    % Scatter for conc2
    conc2=conc2';
    data_flat2 = conc2(:);
    for g = 1:4
        idx = group == g;
        x = randn(sum(idx),1)*0.05 + g + 0.15;
        scatter(x, data_flat2(idx), 100, 'filled', 'MarkerFaceColor', red_dark, 'MarkerFaceAlpha', 0.5)
    end

    % Labels
    xticks(1:4)
    xticklabels(xtick_labels)
    ylabel('CRLB (%)')
    title([metabs{idx1} ' in Vivo CRLB +/- Gly Inclusion'], "FontSize",24)
    %legend({'Yes Gly','No Gly'}, 'Location', 'best')
    hold off

    % change Linewidth for all boxplot elements
    set(findobj(gca,'Tag','Box'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Whisker'),'LineWidth',1)
    set(findobj(gca,'Tag','Median'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Lower Whisker'),'LineWidth',1)
    set(findobj(gca,'Tag','Upper Whisker'),'LineWidth',1)
    set(findobj(gca,'Tag','Upper Adjacent Value'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Lower Adjacent Value'),'LineWidth',1.5)
    set(findobj(gca,'Tag','Outliers'),'MarkerSize',4) %make outliers larger
    box off
    ax = gca;
    ax.XAxis.FontSize = 20;
    ax.YAxis.FontSize = 22;
    ax.XAxis.FontName = 'Arial';

end