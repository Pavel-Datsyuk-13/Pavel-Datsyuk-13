function [frank] = plist(startpat, endpat)
%plist just makes an array with 'p' #'s, makes script less clunky
%1st arg: lowest patient number you are using 
%2nd arg: highest patient number you are using 

frank= cell(1,(endpat-startpat));
for ee = startpat:1:endpat
frank{ee}= ['P',num2str(ee)];
end

end

