% Extracing the csv data for CRLB analysis
%clearvars
% Set reference directory that includes all desired .csv files
baseDir = "path2data";
folders=plist(1,7);%1st number is start patient, second is stop patient
%removing patient 3 bc movement
findP3 = contains(folders, 'P3');
folders(findP3)=[];
% List of metabolites in the path
metabs = {'Asp', 'Cr', 'Cyst', 'GABA', 'Glc', 'Glu', 'Gln',...
    'GPC', 'GSH', 'Ins', 'Lac', 'NAA', 'NAAG', 'PCh', 'PCr',...
    'PE', 'Scyllo', 'Tau', 'Thr'};

for fold_idx = 1:length(folders)
    % Initialize loop #'s and arrays for store
    if fold_idx==1
        num_metabs = length(metabs);
        num_csvs = 4;
        num_pats = length(folders);
        all_concs = zeros(num_csvs, num_metabs, num_pats);
        all_sdevs = zeros(num_csvs, num_metabs, num_pats);
    end
    current_folder=folders{fold_idx};
    currentDir=strcat(baseDir,current_folder);
    % Get list of all CSV files (including subfolders)
    csvFilesStruct = dir(fullfile(currentDir, '**', '*.csv'));
    csv_files = fullfile({csvFilesStruct.folder}, {csvFilesStruct.name});

    desired_order = { 'spreadsheet-LCM_MP_OFF_64ms_3T.csv', 'spreadsheet-LCM_MP_OFF_68ms_3T.csv',...
        'spreadsheet-LCM_MP_SUM_64ms_3T.csv','spreadsheet-LCM_MP_SUM_68ms_3T.csv'};

    % Apply sorting to file names and data
    csv_files = csv_files([1 3 2 4]);
    plot_indices = 1:19;
    %this loop just extracts the data from the csv's
    for csv_idx = 1:num_csvs
        table = readtable(csv_files{csv_idx});
        conctable = table(:,3:3:60); % Mean concentrations
        sdevtable = table(:,4:3:61); % Standard deviations
        % Store data for metabolites, 3rd dim is for each patient
        all_concs(csv_idx,:,fold_idx) = table2array(conctable(1, plot_indices));
        all_sdevs(csv_idx,:, fold_idx) = table2array(sdevtable(1, plot_indices));
    end
end
clc

%% PLotting CRLB for in box plots

%pulling out the mI data and putting into 2d array
mI_CRLB = all_sdevs(:,11,:);
mI_CAT = squeeze(mI_CRLB(:,:,1));
for ii = 2:6
    in1 = mI_CAT;
    in2= squeeze(mI_CRLB(:,:, ii));
    mI_CAT = horzcat(in1, in2);
end
%putting in order of 64ms: off, sum ; 68ms: off, sum
CRLB_mI = mI_CAT';


figure()
data = CRLB_mI(:);
group = repelem(1:4, 6)';
boxplot(data, group)
hold on
% Overlay individual data points with jitter
for g = 1:4
    idx = group == g;
    x = randn(sum(idx),1)*0.05 + g;       % Add jitter to x-axis around group index
    scatter(x, data(idx), 'filled', 'MarkerFaceAlpha', 0.6)
end
xticklabels({'OFF 64','SUM 64','OFF 68','SUM 68'})
ylabel('CRLB (%)')
title('in Vivo mI CRLB without Glycine')
%% Extracting the coords for the background:
clearvars
%rerunning that extraction process. i didn't change variable names btw:

baseDir = "path2data";
folders=plist(1,7);%1st number is start patient, second is stop patient
%removing patient 3 bc movement
findP3 = contains(folders, 'P3');
folders(findP3)=[];

for fold_idx = 1:length(folders)
    % Initialize loop #'s and arrays for store
    if fold_idx==1
        num_csvs = 4;
        num_pats = length(folders);
        Residual_RMS = zeros(num_pats, num_csvs);
        Residual_sums = Residual_RMS;
    end
    current_folder=folders{fold_idx};
    currentDir=strcat(baseDir,current_folder);
    csvFilesStruct = dir(fullfile(currentDir, '**', '*.coord'));
    csv_files = fullfile({csvFilesStruct.folder}, {csvFilesStruct.name});

    desired_order = { strcat(currentDir,'\coord-LCM_MP_OFF_64ms_3T_sl1_1-1.coord'),  strcat(currentDir,'\coord-LCM_MP_SUM_64ms_3T_sl1_1-1.coord'),...
        strcat(currentDir,'\coord-LCM_MP_OFF_68ms_3T_sl1_1-1.coord'),  strcat(currentDir,'\coord-LCM_MP_SUM_68ms_3T_sl1_1-1.coord')};

    % Match and reorder file_names and corresponding data
    csv_files = csv_files([1 3 2 4]);
    coord_names = cell(1, 4);
    for ii=1:4
        coord_names{ii} = csv_files{ii}(66:73);
        coord_names{ii}(4) = " ";
    end

    figure(fold_idx)%for each patient

    for csv_idx = 1:num_csvs
        coordfile = csv_files{csv_idx};
        cur_spec = io_readlcmcoord_getBackground(coordfile,'sp');
        cur_fit = io_readlcmcoord_getBackground(coordfile,'fit');
        cur_baseline = io_readlcmcoord_getBackground(coordfile,'bg');
        ppmrange = find(cur_spec.ppm < 3.7 & cur_spec.ppm > 3.4);     
        ppmplot = cur_baseline.ppm(ppmrange);
        cur_spec = cur_spec.specs(ppmrange);
        cur_fit = cur_fit.specs(ppmrange);
        cur_baseline = cur_baseline.specs(ppmrange);
        cur_residual = cur_spec-cur_fit;
        Residual_RMS(fold_idx, csv_idx) = rms(cur_residual);
        Residual_sums(fold_idx, csv_idx) = sum(abs(cur_residual));
        plot(ppmplot,cur_residual)
        hold on
        legend(coord_names)
        title([folders{fold_idx},':  3.4-3.7 ppm Residuals'])
    end

end
clc

figure()

data = Residual_RMS(:);
group = repelem(1:4, 6)';
boxplot(data, group)
hold on


for g = 1:4
    idx = group == g;
    x = randn(sum(idx),1)*0.05 + g;       % Add jitter to x-axis around group index
    scatter(x, data(idx), 'filled', 'MarkerFaceAlpha', 0.6)
end

xticks(1:4)
xticklabels({'OFF 64','SUM 64','OFF 68','SUM 68'})
ylabel('Residule Root mean square')
title('in Vivo RMS (3.4-3.7 ppm) of residual without Glycine')
set(gca, 'YLim', [300 1600])

hold off
